#pragma once

#include <string>
#include <string_view>
#include <vector>

namespace macrokey {

// Mouse "keys" use negative codes; keyboard keys use Android KeyEvent codes.
inline constexpr int kMouseLeft = -1;
inline constexpr int kMouseRight = -2;
inline constexpr int kMouseMiddle = -3;

struct KeyDef {
    std::string id;    // stored in config, e.g. "k_5", "mouse_left"
    std::string label; // shown in the Mod Menu dropdown
    int code = 0;      // Android keycode, or kMouse*; 0 for "none"
};

// "none" is always the first entry.
const std::vector<KeyDef> &keyTable();
const KeyDef *findKey(std::string_view id);

} // namespace macrokey
