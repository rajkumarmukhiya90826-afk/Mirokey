#include "InputWorker.h"

#include <chrono>

#include "KeyTable.h"

namespace macrokey {

namespace {

// JNI's AttachCurrentThread takes JNIEnv** on the Android NDK and void** on
// desktop JDK headers. Accept both so the file can be syntax-checked anywhere.
template <typename VM> jint attachThread(VM *vm, JNIEnv **env) {
    if constexpr (requires { vm->AttachCurrentThread(env, nullptr); }) {
        return vm->AttachCurrentThread(env, nullptr);
    } else {
        return vm->AttachCurrentThread(reinterpret_cast<void **>(env), nullptr);
    }
}

constexpr int kActionDown = 0; // KeyEvent/MotionEvent ACTION_DOWN
constexpr int kActionUp = 1;   // KeyEvent/MotionEvent ACTION_UP

constexpr int kButtonPrimary = 1;   // MotionEvent.BUTTON_PRIMARY
constexpr int kButtonSecondary = 2; // MotionEvent.BUTTON_SECONDARY
constexpr int kButtonTertiary = 4;  // MotionEvent.BUTTON_TERTIARY
constexpr int kSourceMouse = 0x00002002;
constexpr int kToolTypeMouse = 3;

constexpr std::size_t kMaxQueuedJobs = 8;

} // namespace

void InputWorker::start(JavaVM *vm, pl::log::Logger &logger) {
    std::lock_guard lock(mMutex);
    if (mRunning) {
        return;
    }
    mVm = vm;
    mLog = &logger;
    mStop = false;
    mRunning = true;
    mThread = std::thread([this] { run(); });
}

void InputWorker::stop() {
    {
        std::lock_guard lock(mMutex);
        if (!mRunning) {
            return;
        }
        mStop = true;
    }
    mCv.notify_all();
    if (mThread.joinable()) {
        mThread.join();
    }
    std::lock_guard lock(mMutex);
    mQueue.clear();
    mRunning = false;
}

void InputWorker::post(std::vector<Step> steps) {
    if (steps.empty()) {
        return;
    }
    {
        std::lock_guard lock(mMutex);
        if (!mRunning || mQueue.size() >= kMaxQueuedJobs) {
            return;
        }
        mQueue.push_back(std::move(steps));
    }
    mCv.notify_one();
}

void InputWorker::run() {
    JNIEnv *env = nullptr;
    if (mVm == nullptr || attachThread(mVm, &env) != JNI_OK || env == nullptr) {
        if (mLog) {
            mLog->error("MacroKey: could not attach input worker to the JVM");
        }
        return;
    }

    const bool ready = initJni(env);
    if (!ready && mLog) {
        mLog->error("MacroKey: input injection is unavailable on this device");
    }

    for (;;) {
        std::vector<Step> job;
        {
            std::unique_lock lock(mMutex);
            mCv.wait(lock, [this] { return mStop || !mQueue.empty(); });
            if (mStop) {
                break;
            }
            job = std::move(mQueue.front());
            mQueue.pop_front();
        }
        if (!ready) {
            continue;
        }
        for (const auto &step : job) {
            {
                std::lock_guard lock(mMutex);
                if (mStop) {
                    break;
                }
            }
            if (!exec(env, step)) {
                break;
            }
        }
    }

    releaseJni(env);
    mVm->DetachCurrentThread();
}

bool InputWorker::checkException(JNIEnv *env, const char *what) {
    if (!env->ExceptionCheck()) {
        return true;
    }
    env->ExceptionDescribe();
    env->ExceptionClear();
    if (mLog && !mFailedOnce) {
        mFailedOnce = true;
        mLog->error("MacroKey: JNI call failed: {}", what);
    }
    return false;
}

bool InputWorker::initJni(JNIEnv *env) {
    auto findGlobal = [&](const char *name) -> jclass {
        jclass local = env->FindClass(name);
        if (local == nullptr) {
            env->ExceptionClear();
            return nullptr;
        }
        auto global = static_cast<jclass>(env->NewGlobalRef(local));
        env->DeleteLocalRef(local);
        return global;
    };

    jclass instClass = env->FindClass("android/app/Instrumentation");
    if (instClass == nullptr) {
        env->ExceptionClear();
        return false;
    }
    jmethodID instCtor = env->GetMethodID(instClass, "<init>", "()V");
    mSendKeySync = env->GetMethodID(instClass, "sendKeySync", "(Landroid/view/KeyEvent;)V");
    mSendPointerSync =
        env->GetMethodID(instClass, "sendPointerSync", "(Landroid/view/MotionEvent;)V");
    if (!checkException(env, "Instrumentation lookup") || instCtor == nullptr) {
        return false;
    }
    jobject inst = env->NewObject(instClass, instCtor);
    env->DeleteLocalRef(instClass);
    if (!checkException(env, "new Instrumentation") || inst == nullptr) {
        return false;
    }
    mInst = env->NewGlobalRef(inst);
    env->DeleteLocalRef(inst);

    mKeyClass = findGlobal("android/view/KeyEvent");
    mClockClass = findGlobal("android/os/SystemClock");
    mMotionClass = findGlobal("android/view/MotionEvent");
    mPpClass = findGlobal("android/view/MotionEvent$PointerProperties");
    mPcClass = findGlobal("android/view/MotionEvent$PointerCoords");
    if (!mKeyClass || !mClockClass || !mMotionClass || !mPpClass || !mPcClass) {
        return false;
    }

    mKeyCtor = env->GetMethodID(mKeyClass, "<init>", "(JJIII)V");
    mUptime = env->GetStaticMethodID(mClockClass, "uptimeMillis", "()J");
    mObtain = env->GetStaticMethodID(
        mMotionClass, "obtain",
        "(JJII[Landroid/view/MotionEvent$PointerProperties;"
        "[Landroid/view/MotionEvent$PointerCoords;IIFFIIII)Landroid/view/MotionEvent;");
    mPpCtor = env->GetMethodID(mPpClass, "<init>", "()V");
    mPcCtor = env->GetMethodID(mPcClass, "<init>", "()V");
    mPpId = env->GetFieldID(mPpClass, "id", "I");
    mPpTool = env->GetFieldID(mPpClass, "toolType", "I");
    mPcX = env->GetFieldID(mPcClass, "x", "F");
    mPcY = env->GetFieldID(mPcClass, "y", "F");
    mPcPressure = env->GetFieldID(mPcClass, "pressure", "F");
    mPcSize = env->GetFieldID(mPcClass, "size", "F");
    return checkException(env, "JNI handle lookup");
}

void InputWorker::releaseJni(JNIEnv *env) {
    for (jobject ref : {mInst, static_cast<jobject>(mKeyClass), static_cast<jobject>(mClockClass),
                        static_cast<jobject>(mMotionClass), static_cast<jobject>(mPpClass),
                        static_cast<jobject>(mPcClass)}) {
        if (ref != nullptr) {
            env->DeleteGlobalRef(ref);
        }
    }
    mInst = nullptr;
    mKeyClass = mClockClass = mMotionClass = mPpClass = mPcClass = nullptr;
}

bool InputWorker::exec(JNIEnv *env, const Step &step) {
    switch (step.kind) {
    case Step::Kind::Sleep:
        std::this_thread::sleep_for(std::chrono::milliseconds(step.value));
        return true;
    case Step::Kind::KeyDown:
        return sendKey(env, kActionDown, step.value);
    case Step::Kind::KeyUp:
        return sendKey(env, kActionUp, step.value);
    case Step::Kind::MouseDown:
        return sendMouse(env, kActionDown, step.value, step.x, step.y);
    case Step::Kind::MouseUp:
        return sendMouse(env, kActionUp, step.value, step.x, step.y);
    }
    return true;
}

bool InputWorker::sendKey(JNIEnv *env, int action, int code) {
    const jlong now = env->CallStaticLongMethod(mClockClass, mUptime);
    if (action == kActionDown) {
        mKeyDownTime = now;
    }
    jobject ev = env->NewObject(mKeyClass, mKeyCtor, mKeyDownTime, now, static_cast<jint>(action),
                                static_cast<jint>(code), static_cast<jint>(0));
    if (!checkException(env, "new KeyEvent") || ev == nullptr) {
        return false;
    }
    env->CallVoidMethod(mInst, mSendKeySync, ev);
    env->DeleteLocalRef(ev);
    return checkException(env, "sendKeySync");
}

bool InputWorker::sendMouse(JNIEnv *env, int action, int mouseCode, float x, float y) {
    int buttonState = 0;
    if (action == kActionDown) {
        switch (mouseCode) {
        case kMouseLeft:
            buttonState = kButtonPrimary;
            break;
        case kMouseRight:
            buttonState = kButtonSecondary;
            break;
        case kMouseMiddle:
            buttonState = kButtonTertiary;
            break;
        default:
            return true;
        }
    }

    const jlong now = env->CallStaticLongMethod(mClockClass, mUptime);
    if (action == kActionDown) {
        mMouseDownTime = now;
    }

    jobject pp = env->NewObject(mPpClass, mPpCtor);
    jobject pc = env->NewObject(mPcClass, mPcCtor);
    if (!checkException(env, "new PointerProperties/Coords") || pp == nullptr || pc == nullptr) {
        return false;
    }
    env->SetIntField(pp, mPpId, 0);
    env->SetIntField(pp, mPpTool, kToolTypeMouse);
    env->SetFloatField(pc, mPcX, x);
    env->SetFloatField(pc, mPcY, y);
    env->SetFloatField(pc, mPcPressure, 1.0f);
    env->SetFloatField(pc, mPcSize, 1.0f);

    jobjectArray ppArr = env->NewObjectArray(1, mPpClass, pp);
    jobjectArray pcArr = env->NewObjectArray(1, mPcClass, pc);
    jobject ev = env->CallStaticObjectMethod(
        mMotionClass, mObtain, mMouseDownTime, now, static_cast<jint>(action),
        static_cast<jint>(1), ppArr, pcArr, static_cast<jint>(0),
        static_cast<jint>(buttonState), 1.0f, 1.0f, static_cast<jint>(0),
        static_cast<jint>(0), static_cast<jint>(kSourceMouse), static_cast<jint>(0));

    env->DeleteLocalRef(pp);
    env->DeleteLocalRef(pc);
    env->DeleteLocalRef(ppArr);
    env->DeleteLocalRef(pcArr);
    if (!checkException(env, "MotionEvent.obtain") || ev == nullptr) {
        return false;
    }
    env->CallVoidMethod(mInst, mSendPointerSync, ev);
    env->DeleteLocalRef(ev);
    return checkException(env, "sendPointerSync");
}

} // namespace macrokey
