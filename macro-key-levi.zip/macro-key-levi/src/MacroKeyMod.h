#pragma once

#include <array>
#include <mutex>
#include <string>
#include <string_view>
#include <vector>

#include <pl/Mod.hpp>

#include "InputWorker.h"

namespace macrokey {

inline constexpr int kMacroCount = 5;  // macro buttons that can be added
inline constexpr int kActionSlots = 4; // key/click slots per macro button

struct MacroDef {
    bool enabled = false;
    std::string label;
    std::array<std::string, kActionSlots> action{"none", "none", "none", "none"};
    std::string mode = "sequence"; // "sequence" or "together"
    int delayMs = 50;
};

class MacroKeyMod {
public:
    static MacroKeyMod &instance();
    MacroKeyMod();

    bool load();
    bool enable();
    bool disable();
    bool unload();

private:
    std::string buildSchema();
    void onConfigChanged(std::string_view key, std::string_view value);
    void onButtonEvent(std::string_view buttonId, int event);
    void refreshButton(int index);
    void removeButton(int index);
    void runMacro(int index);

    void loadFile();
    void saveFile();

    ll::mod::NativeMod *mSelf = nullptr;
    std::mutex mMutex;
    std::array<MacroDef, kMacroCount> mMacros;
    std::array<bool, kMacroCount> mButtonRegistered{};
    InputWorker mWorker;
    bool mModuleRegistered = false;
};

} // namespace macrokey
