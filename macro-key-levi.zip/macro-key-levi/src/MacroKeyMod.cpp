#include "MacroKeyMod.h"

#include <algorithm>
#include <charconv>
#include <filesystem>
#include <fstream>
#include <string>

#include <pl/ModMenu.hpp>

#include "KeyTable.h"

namespace macrokey {

namespace {

constexpr const char *kModuleId = "macro-key.module";
constexpr const char *kButtonPrefix = "macro-key.btn_";
constexpr const char *kConfigFile = "macros.cfg";
constexpr std::size_t kMaxLabelBytes = 12;
constexpr int kMaxDelayMs = 500;

// The Mod Menu rejects schemas with more than 2048 dropdown options in total.
static_assert(kMacroCount * kActionSlots * 100 + kMacroCount * 2 <= 2048,
              "too many macro dropdown options for the Mod Menu schema limit");

bool parseBool(std::string_view v) {
    return v == "true" || v == "1" || v == "on" || v == "enabled";
}

int parseInt(std::string_view v, int fallback) {
    int out = 0;
    const auto [ptr, ec] = std::from_chars(v.data(), v.data() + v.size(), out);
    if (ec != std::errc() || ptr != v.data() + v.size()) {
        return fallback;
    }
    return out;
}

std::string cutLabel(std::string_view v) {
    std::string s(v);
    if (s.size() > kMaxLabelBytes) {
        s.resize(kMaxLabelBytes);
        // do not leave half a UTF-8 character behind
        while (!s.empty() && (static_cast<unsigned char>(s.back()) & 0xC0) == 0x80) {
            s.pop_back();
        }
        if (!s.empty() && (static_cast<unsigned char>(s.back()) & 0xC0) == 0xC0) {
            s.pop_back();
        }
    }
    return s;
}

std::string defaultLabel(int index) { return "M" + std::to_string(index + 1); }

std::string macroKey(int index, const std::string &field) {
    return "m" + std::to_string(index + 1) + "_" + field;
}

// "m3_a2" -> index 2, field "a2"
bool splitKey(std::string_view key, int &index, std::string_view &field) {
    if (key.size() < 4 || key[0] != 'm' || key[1] < '1' || key[1] > '9' || key[2] != '_') {
        return false;
    }
    index = (key[1] - '0') - 1;
    field = key.substr(3);
    return index >= 0 && index < kMacroCount;
}

// Returns an Android key code when the macro is exactly one keyboard key.
// The launcher can send that natively; everything else is injected by us.
int singleKeyboardCode(const MacroDef &def) {
    int code = 0;
    int count = 0;
    for (const auto &id : def.action) {
        const KeyDef *k = findKey(id);
        if (k == nullptr || k->code == 0) {
            continue;
        }
        ++count;
        code = k->code;
    }
    return (count == 1 && code > 0) ? code : 0;
}

} // namespace

MacroKeyMod &MacroKeyMod::instance() {
    static MacroKeyMod mod;
    return mod;
}

MacroKeyMod::MacroKeyMod() : mSelf(ll::mod::NativeMod::current()) {
    for (int i = 0; i < kMacroCount; ++i) {
        mMacros[i].label = defaultLabel(i);
    }
}

bool MacroKeyMod::load() {
    if (mSelf == nullptr) {
        return false;
    }
    std::error_code ec;
    std::filesystem::create_directories(mSelf->getConfigDir(), ec);
    loadFile();
    mSelf->getLogger().info("MacroKey loaded");
    return true;
}

bool MacroKeyMod::enable() {
    auto &self = *mSelf;
    mWorker.start(self.getJavaVM(), self.getLogger());

    mModuleRegistered =
        pl::modmenu::ModuleBuilder(kModuleId, "Macro Key")
            .modId(self.getId())
            .description("Ek button me 4 tak keys / clicks. Neeche 'Add button' on karo, phir "
                         "Action 1-4 me key ya Left Click chuno.")
            .defaultEnabled(true)
            .onConfigChanged([this](std::string_view, std::string_view key, std::string_view value) {
                onConfigChanged(key, value);
            })
            .registerModule();
    if (!mModuleRegistered) {
        self.getLogger().error("MacroKey: Mod Menu module registration failed");
        return false;
    }

    if (!pl::modmenu::setConfigSchemaJson(kModuleId, buildSchema())) {
        self.getLogger().error("MacroKey: Mod Menu config schema was rejected");
    }

    for (int i = 0; i < kMacroCount; ++i) {
        refreshButton(i);
    }
    self.getLogger().info("MacroKey enabled");
    return true;
}

bool MacroKeyMod::disable() {
    for (int i = 0; i < kMacroCount; ++i) {
        removeButton(i);
    }
    if (mModuleRegistered) {
        pl::modmenu::unregisterModule(kModuleId);
        mModuleRegistered = false;
    }
    mWorker.stop();
    saveFile();
    if (mSelf != nullptr) {
        mSelf->getLogger().info("MacroKey disabled");
    }
    return true;
}

bool MacroKeyMod::unload() { return true; }

// ---------------------------------------------------------------------------
// Mod Menu schema: per macro -> "Add button" toggle, label, 4 action dropdowns
// (full key list + clicks), mode and delay. Everything except the toggle is
// hidden until the button is added.
// ---------------------------------------------------------------------------

std::string MacroKeyMod::buildSchema() {
    using namespace pl::modmenu;

    std::array<MacroDef, kMacroCount> macros;
    {
        std::lock_guard lock(mMutex);
        macros = mMacros;
    }

    ConfigSchemaBuilder schema;
    schema.category("macros", "Macro Buttons",
                    "Har macro ek on-screen button banata hai. Button HUD editor me kahin bhi "
                    "rakh sakte ho.");
    schema.defaultCategory("macros");

    for (int i = 0; i < kMacroCount; ++i) {
        const MacroDef &def = macros[i];
        const std::string enabledKey = macroKey(i, "enabled");

        auto base = [&](const std::string &field, ConfigControlTypeV2 type,
                        const std::string &title) {
            ConfigNodeV2 n;
            n.id = macroKey(i, field);
            n.key = macroKey(i, field);
            n.category = "macros";
            n.title = title;
            n.type = type;
            if (field != "enabled") {
                n.visibleWhen.push_back({enabledKey, ConfigConditionOpV2::Truthy, ""});
            }
            return n;
        };

        ConfigNodeV2 section;
        section.id = macroKey(i, "section");
        section.category = "macros";
        section.title = "Macro " + std::to_string(i + 1);
        section.type = ConfigControlTypeV2::Section;
        schema.node(std::move(section));

        ConfigNodeV2 enabled = base("enabled", ConfigControlTypeV2::Toggle,
                                    "Add button (Macro " + std::to_string(i + 1) + ")");
        enabled.defaultValue = def.enabled ? "true" : "false";
        enabled.currentValue = enabled.defaultValue;
        enabled.hasCurrentValue = true;
        schema.node(std::move(enabled));

        ConfigNodeV2 label = base("label", ConfigControlTypeV2::Text, "Button name");
        label.defaultValue = def.label;
        label.currentValue = def.label;
        label.hasCurrentValue = true;
        label.maxLength = static_cast<int>(kMaxLabelBytes);
        schema.node(std::move(label));

        for (int s = 0; s < kActionSlots; ++s) {
            ConfigNodeV2 action = base("a" + std::to_string(s + 1), ConfigControlTypeV2::Choice,
                                       "Action " + std::to_string(s + 1));
            action.choiceStyle = ConfigChoiceStyleV2::Dropdown;
            action.searchable = true;
            action.defaultValue = def.action[s];
            action.currentValue = def.action[s];
            action.hasCurrentValue = true;
            for (const auto &k : keyTable()) {
                ConfigOptionV2 opt;
                opt.value = k.id;
                opt.label = k.label;
                action.options.push_back(std::move(opt));
            }
            schema.node(std::move(action));
        }

        ConfigNodeV2 mode = base("mode", ConfigControlTypeV2::Choice, "Kaise chalayein");
        mode.choiceStyle = ConfigChoiceStyleV2::Segmented;
        mode.defaultValue = def.mode;
        mode.currentValue = def.mode;
        mode.hasCurrentValue = true;
        ConfigOptionV2 seq;
        seq.value = "sequence";
        seq.label = "Ek ke baad ek";
        ConfigOptionV2 tog;
        tog.value = "together";
        tog.label = "Saath me";
        mode.options.push_back(std::move(seq));
        mode.options.push_back(std::move(tog));
        schema.node(std::move(mode));

        ConfigNodeV2 delay = base("delay", ConfigControlTypeV2::SliderInt, "Delay / hold (ms)");
        delay.defaultValue = std::to_string(def.delayMs);
        delay.currentValue = delay.defaultValue;
        delay.hasCurrentValue = true;
        delay.minValue = "0";
        delay.maxValue = std::to_string(kMaxDelayMs);
        delay.step = "10";
        delay.unit = "ms";
        schema.node(std::move(delay));
    }

    return schema.toJson();
}

// ---------------------------------------------------------------------------
// Config changes coming from the Mod Menu
// ---------------------------------------------------------------------------

void MacroKeyMod::onConfigChanged(std::string_view key, std::string_view value) {
    int index = 0;
    std::string_view field;
    if (!splitKey(key, index, field)) {
        return;
    }

    {
        std::lock_guard lock(mMutex);
        MacroDef &def = mMacros[index];
        if (field == "enabled") {
            def.enabled = parseBool(value);
        } else if (field == "label") {
            def.label = value.empty() ? defaultLabel(index) : cutLabel(value);
        } else if (field.size() == 2 && field[0] == 'a' && field[1] >= '1' &&
                   field[1] <= '0' + kActionSlots) {
            const int slot = field[1] - '1';
            def.action[slot] = findKey(value) != nullptr ? std::string(value) : "none";
        } else if (field == "mode") {
            def.mode = (value == "together") ? "together" : "sequence";
        } else if (field == "delay") {
            def.delayMs = std::clamp(parseInt(value, def.delayMs), 0, kMaxDelayMs);
        } else {
            return;
        }
    }

    saveFile();
    // Label and first/only key are baked into the registered button.
    refreshButton(index);
}

// ---------------------------------------------------------------------------
// On-screen buttons
// ---------------------------------------------------------------------------

void MacroKeyMod::removeButton(int index) {
    if (mButtonRegistered[index]) {
        pl::modmenu::unregisterButton(std::string(kButtonPrefix) + std::to_string(index + 1));
        mButtonRegistered[index] = false;
    }
}

void MacroKeyMod::refreshButton(int index) {
    if (mSelf == nullptr || !mModuleRegistered) {
        return;
    }

    MacroDef def;
    {
        std::lock_guard lock(mMutex);
        def = mMacros[index];
    }

    removeButton(index);
    if (!def.enabled) {
        return;
    }

    const std::string buttonId = std::string(kButtonPrefix) + std::to_string(index + 1);
    const bool ok =
        pl::modmenu::ButtonBuilder(buttonId, "Macro Key: " + def.label)
            .moduleId(kModuleId)
            .modId(mSelf->getId())
            .label(def.label)
            .androidKeyCode(singleKeyboardCode(def))
            .behavior(pl::modmenu::ButtonBehavior::Click)
            .stylePreset(pl::modmenu::ButtonStylePreset::Keycap)
            .sizeScale(1.0f, 1.0f)
            .onEvent([this](std::string_view id, pl::modmenu::ButtonEvent event, float) {
                onButtonEvent(id, static_cast<int>(event));
            })
            .registerButton();
    mButtonRegistered[index] = ok;
    if (!ok) {
        mSelf->getLogger().error("MacroKey: could not register button {}", buttonId);
    }
}

void MacroKeyMod::onButtonEvent(std::string_view buttonId, int event) {
    if (event != static_cast<int>(pl::modmenu::ButtonEvent::Click)) {
        return;
    }
    constexpr std::string_view prefix = kButtonPrefix;
    if (buttonId.size() <= prefix.size() || buttonId.substr(0, prefix.size()) != prefix) {
        return;
    }
    const int number = parseInt(buttonId.substr(prefix.size()), 0);
    if (number >= 1 && number <= kMacroCount) {
        runMacro(number - 1);
    }
}

// ---------------------------------------------------------------------------
// Running a macro
// ---------------------------------------------------------------------------

void MacroKeyMod::runMacro(int index) {
    MacroDef def;
    {
        std::lock_guard lock(mMutex);
        def = mMacros[index];
    }

    // Exactly one keyboard key: the launcher already sent it via androidKeyCode.
    if (singleKeyboardCode(def) != 0) {
        return;
    }

    const auto surface = pl::modmenu::getHudSurfaceSize();
    const float cx = surface.width > 0.0f ? surface.width * 0.5f : 540.0f;
    const float cy = surface.height > 0.0f ? surface.height * 0.5f : 1170.0f;

    std::vector<const KeyDef *> keys;
    for (const auto &id : def.action) {
        const KeyDef *k = findKey(id);
        if (k != nullptr && k->code != 0) {
            keys.push_back(k);
        }
    }
    if (keys.empty()) {
        return;
    }

    auto stepFor = [&](const KeyDef *k, bool down) {
        Step s;
        if (k->code < 0) {
            s.kind = down ? Step::Kind::MouseDown : Step::Kind::MouseUp;
            s.x = cx;
            s.y = cy;
        } else {
            s.kind = down ? Step::Kind::KeyDown : Step::Kind::KeyUp;
        }
        s.value = k->code;
        return s;
    };
    auto sleepStep = [](int ms) {
        Step s;
        s.kind = Step::Kind::Sleep;
        s.value = ms;
        return s;
    };

    std::vector<Step> steps;
    if (def.mode == "together") {
        for (const KeyDef *k : keys) {
            steps.push_back(stepFor(k, true));
        }
        steps.push_back(sleepStep(std::max(def.delayMs, 20)));
        for (auto it = keys.rbegin(); it != keys.rend(); ++it) {
            steps.push_back(stepFor(*it, false));
        }
    } else {
        for (std::size_t i = 0; i < keys.size(); ++i) {
            steps.push_back(stepFor(keys[i], true));
            steps.push_back(sleepStep(std::max(def.delayMs, 20)));
            steps.push_back(stepFor(keys[i], false));
            if (i + 1 < keys.size()) {
                steps.push_back(sleepStep(def.delayMs));
            }
        }
    }
    mWorker.post(std::move(steps));
}

// ---------------------------------------------------------------------------
// Persistence: config/macros.cfg, one "key=value" per line
// ---------------------------------------------------------------------------

void MacroKeyMod::loadFile() {
    std::ifstream in(mSelf->getConfigDir() / kConfigFile);
    if (!in) {
        return;
    }
    std::string line;
    while (std::getline(in, line)) {
        const auto eq = line.find('=');
        if (eq == std::string::npos) {
            continue;
        }
        const std::string key = line.substr(0, eq);
        const std::string value = line.substr(eq + 1);
        int index = 0;
        std::string_view field;
        if (!splitKey(key, index, field)) {
            continue;
        }
        MacroDef &def = mMacros[index];
        if (field == "enabled") {
            def.enabled = parseBool(value);
        } else if (field == "label") {
            def.label = value.empty() ? defaultLabel(index) : cutLabel(value);
        } else if (field.size() == 2 && field[0] == 'a' && field[1] >= '1' &&
                   field[1] <= '0' + kActionSlots) {
            def.action[field[1] - '1'] = findKey(value) != nullptr ? value : "none";
        } else if (field == "mode") {
            def.mode = (value == "together") ? "together" : "sequence";
        } else if (field == "delay") {
            def.delayMs = std::clamp(parseInt(value, def.delayMs), 0, kMaxDelayMs);
        }
    }
}

void MacroKeyMod::saveFile() {
    if (mSelf == nullptr) {
        return;
    }
    std::array<MacroDef, kMacroCount> copy;
    {
        std::lock_guard lock(mMutex);
        copy = mMacros;
    }
    std::error_code ec;
    std::filesystem::create_directories(mSelf->getConfigDir(), ec);
    std::ofstream out(mSelf->getConfigDir() / kConfigFile, std::ios::trunc);
    if (!out) {
        return;
    }
    for (int i = 0; i < kMacroCount; ++i) {
        const MacroDef &d = copy[i];
        out << macroKey(i, "enabled") << '=' << (d.enabled ? "true" : "false") << '\n';
        out << macroKey(i, "label") << '=' << d.label << '\n';
        for (int s = 0; s < kActionSlots; ++s) {
            out << macroKey(i, "a" + std::to_string(s + 1)) << '=' << d.action[s] << '\n';
        }
        out << macroKey(i, "mode") << '=' << d.mode << '\n';
        out << macroKey(i, "delay") << '=' << d.delayMs << '\n';
    }
}

} // namespace macrokey
