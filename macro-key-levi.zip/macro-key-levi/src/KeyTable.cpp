#include "KeyTable.h"

namespace macrokey {

namespace {

std::vector<KeyDef> build() {
    std::vector<KeyDef> v;
    v.reserve(96);

    v.push_back({"none", "(Khali)", 0});
    v.push_back({"mouse_left", "Left Click", kMouseLeft});
    v.push_back({"mouse_right", "Right Click", kMouseRight});
    v.push_back({"mouse_middle", "Middle Click", kMouseMiddle});

    // Android KEYCODE_0..9 = 7..16
    for (int d = 0; d <= 9; ++d) {
        v.push_back({"k_" + std::to_string(d), "Key " + std::to_string(d), 7 + d});
    }
    // Android KEYCODE_A..Z = 29..54
    for (int i = 0; i < 26; ++i) {
        const char lower = static_cast<char>('a' + i);
        const char upper = static_cast<char>('A' + i);
        v.push_back({std::string("k_") + lower, std::string("Key ") + upper, 29 + i});
    }
    // Android KEYCODE_F1..F12 = 131..142
    for (int n = 1; n <= 12; ++n) {
        v.push_back({"f" + std::to_string(n), "F" + std::to_string(n), 130 + n});
    }

    v.push_back({"up", "Arrow Up", 19});
    v.push_back({"down", "Arrow Down", 20});
    v.push_back({"left", "Arrow Left", 21});
    v.push_back({"right", "Arrow Right", 22});

    v.push_back({"space", "Space", 62});
    v.push_back({"enter", "Enter", 66});
    v.push_back({"tab", "Tab", 61});
    v.push_back({"esc", "Escape", 111});
    v.push_back({"backspace", "Backspace", 67});
    v.push_back({"delete", "Delete", 112});
    v.push_back({"shift_l", "Shift (Left)", 59});
    v.push_back({"shift_r", "Shift (Right)", 60});
    v.push_back({"ctrl_l", "Ctrl (Left)", 113});
    v.push_back({"ctrl_r", "Ctrl (Right)", 114});
    v.push_back({"alt_l", "Alt (Left)", 57});
    v.push_back({"alt_r", "Alt (Right)", 58});
    v.push_back({"caps", "Caps Lock", 115});

    v.push_back({"comma", "Comma ,", 55});
    v.push_back({"period", "Period .", 56});
    v.push_back({"slash", "Slash /", 76});
    v.push_back({"semicolon", "Semicolon ;", 74});
    v.push_back({"apostrophe", "Apostrophe '", 75});
    v.push_back({"lbracket", "Bracket [", 71});
    v.push_back({"rbracket", "Bracket ]", 72});
    v.push_back({"backslash", "Backslash", 73});
    v.push_back({"minus", "Minus -", 69});
    v.push_back({"equals", "Equals =", 70});
    v.push_back({"grave", "Grave `", 68});

    v.push_back({"home", "Home", 122});
    v.push_back({"end", "End", 123});
    v.push_back({"pageup", "Page Up", 92});
    v.push_back({"pagedown", "Page Down", 93});
    v.push_back({"insert", "Insert", 124});

    // Android KEYCODE_NUMPAD_0..9 = 144..153
    for (int d = 0; d <= 9; ++d) {
        v.push_back({"np_" + std::to_string(d), "Numpad " + std::to_string(d), 144 + d});
    }
    return v;
}

} // namespace

const std::vector<KeyDef> &keyTable() {
    static const std::vector<KeyDef> table = build();
    return table;
}

const KeyDef *findKey(std::string_view id) {
    for (const auto &k : keyTable()) {
        if (k.id == id) {
            return &k;
        }
    }
    return nullptr;
}

} // namespace macrokey
