#include "MacroKeyMod.h"

#include <pl/Mod.hpp>

PL_REGISTER_MOD(macrokey::MacroKeyMod, macrokey::MacroKeyMod::instance())
