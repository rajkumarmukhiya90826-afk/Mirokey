#pragma once

#include <jni.h>

#include <condition_variable>
#include <deque>
#include <mutex>
#include <thread>
#include <vector>

#include <pl/Logger.hpp>

namespace macrokey {

struct Step {
    enum class Kind { KeyDown, KeyUp, MouseDown, MouseUp, Sleep };
    Kind kind = Kind::Sleep;
    int value = 0;  // key code / mouse code (kMouse*) / sleep ms
    float x = 0.0f; // mouse position (px)
    float y = 0.0f;
};

// Runs input sequences on its own thread. Android's Instrumentation input
// injection must not be called from the app's main thread, and the launcher
// calls our button callbacks from the UI thread.
class InputWorker {
public:
    InputWorker() = default;
    InputWorker(const InputWorker &) = delete;
    InputWorker &operator=(const InputWorker &) = delete;
    ~InputWorker() { stop(); }

    void start(JavaVM *vm, pl::log::Logger &logger);
    void stop();
    void post(std::vector<Step> steps);

private:
    void run();
    bool initJni(JNIEnv *env);
    void releaseJni(JNIEnv *env);
    bool exec(JNIEnv *env, const Step &step);
    bool sendKey(JNIEnv *env, int action, int code);
    bool sendMouse(JNIEnv *env, int action, int mouseCode, float x, float y);
    bool checkException(JNIEnv *env, const char *what);

    JavaVM *mVm = nullptr;
    pl::log::Logger *mLog = nullptr;

    std::thread mThread;
    std::mutex mMutex;
    std::condition_variable mCv;
    std::deque<std::vector<Step>> mQueue;
    bool mStop = false;
    bool mRunning = false;

    // JNI handles (valid only on the worker thread)
    jobject mInst = nullptr;
    jclass mKeyClass = nullptr;
    jclass mClockClass = nullptr;
    jclass mMotionClass = nullptr;
    jclass mPpClass = nullptr;
    jclass mPcClass = nullptr;
    jmethodID mSendKeySync = nullptr;
    jmethodID mSendPointerSync = nullptr;
    jmethodID mKeyCtor = nullptr;
    jmethodID mUptime = nullptr;
    jmethodID mObtain = nullptr;
    jmethodID mPpCtor = nullptr;
    jmethodID mPcCtor = nullptr;
    jfieldID mPpId = nullptr;
    jfieldID mPpTool = nullptr;
    jfieldID mPcX = nullptr;
    jfieldID mPcY = nullptr;
    jfieldID mPcPressure = nullptr;
    jfieldID mPcSize = nullptr;

    jlong mKeyDownTime = 0;
    jlong mMouseDownTime = 0;
    bool mFailedOnce = false;
};

} // namespace macrokey
