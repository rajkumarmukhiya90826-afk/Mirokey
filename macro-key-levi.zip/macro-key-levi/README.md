# Macro Key (LeviLauncher Android mod)

Ek on-screen macro button, jisme 4 tak keys / clicks set hote hain (Pojav ke button editor jaisa).

## .levipack banana (GitHub Actions)

1. Is folder ko ek naye GitHub repo me upload karo (`third_party/` folder samet).
2. Repo me **Actions -> Build levipack -> Run workflow** dabao.
3. Run khatam hone par **Artifacts -> macro-key-levipacks** download karo. Andar
   `macro-key-1.0.0-arm64-v8a.levipack` milega (zyadatar phones ke liye yehi chahiye).

Local build: `ANDROID_NDK_HOME=<ndk r28b> ./scripts/build.sh` -> `dist/*.levipack`.

## Install

LeviLauncher -> Mods -> Import -> `.levipack` chuno. Game chalao.

## Use

1. Mod Menu kholo -> **Macro Key** module.
2. **Macro 1 -> Add button** ON karo. Ek on-screen button aa jayega (HUD editor se kahin bhi rakh sakte ho).
3. **Action 1..4** me dropdown se key ya Left Click chuno (poora keyboard, F1-F12, numpad, mouse buttons).
   Wind charge ke liye: Action 1 = `Key 5` (jis slot me wind charge hai uska number).
4. **Kaise chalayein**: *Ek ke baad ek* (pehle Action 1, phir 2, ...) ya *Saath me* (sab ek saath, chord).
5. Delay slider se keys ke beech ka gap / hold time set hota hai.

Kul 5 macro buttons hain.

## Kaise kaam karta hai

- Sirf **ek keyboard key** wala macro launcher ke apne `androidKeyCode` se chalta hai.
- Ek se zyada action ya koi **click** ho to mod Android ke `Instrumentation` se key/mouse events
  game window me bhejta hai (alag thread par). Click screen ke beech me jata hai.

## Dhyan do

- Compile hone ki jaanch sirf Preloader SDK ke headers ke against hui hai. Phone par key/click
  injection abhi test nahi hua; agar kuch nahi chale to `logcat` me tag `Macro Key` dekho.
- SDK `third_party/preloader-android` me bundled hai (jo copy tumne bheji thi). LeviLauncher ka version
  usi SDK jaisa naya hona chahiye, warna mod load nahi hoga.
- Hive jaise servers macros par ban kar sakte hain. Apne risk par use karo.
