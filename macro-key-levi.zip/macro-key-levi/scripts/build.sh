#!/usr/bin/env bash
# Builds the Macro Key .levipack for LeviLauncher Android.
#   ./scripts/build.sh            -> arm64-v8a
#   ./scripts/build.sh all        -> arm64-v8a + armeabi-v7a
# Needs: Android NDK r28b (ANDROID_NDK_HOME), cmake >= 3.22, ninja.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(dirname "$SCRIPT_DIR")"

ABI_LIST="${1:-arm64-v8a}"
ANDROID_PLATFORM="${ANDROID_PLATFORM:-android-28}"

NDK_HOME="${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}"
if [[ -z "$NDK_HOME" || ! -f "$NDK_HOME/build/cmake/android.toolchain.cmake" ]]; then
  echo "error: Android NDK not found. Set ANDROID_NDK_HOME to an NDK r28b folder." >&2
  exit 1
fi
command -v cmake >/dev/null || { echo "error: cmake not found" >&2; exit 1; }
command -v ninja >/dev/null || { echo "error: ninja not found (pip install ninja)" >&2; exit 1; }

if [[ "$ABI_LIST" == "all" ]]; then
  ABI_LIST="arm64-v8a armeabi-v7a"
fi

mkdir -p "$REPO_ROOT/dist"
for ABI in $ABI_LIST; do
  BUILD_DIR="$REPO_ROOT/build/android-$ABI"
  cmake -S "$REPO_ROOT" -B "$BUILD_DIR" -G Ninja \
    -DCMAKE_TOOLCHAIN_FILE="$NDK_HOME/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI="$ABI" \
    -DANDROID_PLATFORM="$ANDROID_PLATFORM" \
    -DANDROID_STL=c++_shared \
    -DCMAKE_BUILD_TYPE=Release

  cmake --build "$BUILD_DIR" --target levi_package -j2

  PACK_FILE="$(ls "$BUILD_DIR"/*.levipack 2>/dev/null | head -1 || true)"
  if [[ -z "$PACK_FILE" ]]; then
    echo "error: no .levipack produced in $BUILD_DIR" >&2
    exit 1
  fi
  cp "$PACK_FILE" "$REPO_ROOT/dist/"
  echo "Packaged: dist/$(basename "$PACK_FILE")"
done
